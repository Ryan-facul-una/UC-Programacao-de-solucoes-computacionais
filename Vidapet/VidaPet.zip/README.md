
  # Criar 3 Telas para Projeto

  This is a code bundle for Criar 3 Telas para Projeto. The original project is available at https://www.figma.com/design/nvADzsx0oYbWVI8VDleOAs/Criar-3-Telas-para-Projeto.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  